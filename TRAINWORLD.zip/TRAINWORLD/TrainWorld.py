import time
import pygame
pygame.init()
print ("-============================================================================-")
time.sleep(0.1)
print ("TrainWorld has opened. Have fun!")
time.sleep(0.1)
print ("-============================================================================-")
time.sleep(1)
icon = pygame.image.load('icon.ico')
pygame.display.set_icon(icon)
background_colour = (255,255,255)
(width, height) = (1280, 700)
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption('TrainWorld')
icon = pygame.image.load("icon.ico")
background = pygame.image.load("Grass.bmp")
titlelogo = pygame.image.load('Assets/logo.png')
screen.fill(background_colour)
screen.blit(background, (0, 0))
screen.blit(titlelogo, (487, 140))
pygame.display.flip()

#loading images
start_img = pygame.image.load('Assets/playbutton.png').convert_alpha()

#button class
class Button():
  def __init__(self, x, y, image):
      self.image = image
      self.rect = self.image.get_rect()
      self.rect.topleft = (x, y)
    
  def draw(self):
    screen.blit(self.image, (self.rect.x, self.rect.y))
    

#create button instance
start_button = Button(440, 200, start_img)

#Game Loop

running = True
while running:
  start_button.draw()
    
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = False